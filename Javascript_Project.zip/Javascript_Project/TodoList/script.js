let task_input = document.getElementById("task_input");
let add_task = document.getElementById("add_task");
let task_list = document.getElementById("task_list");

add_task.addEventListener('click', () => {
  //e.preventDefault();
  let task = task_input.value.trim();
  if (task != '') {
    let li = document.createElement('li');
    li.textContent = task;
    // delete bitton
    let delete_btn = document.createElement('button');
    delete_btn.textContent = "Delete";
    delete_btn.style.marginLeft = "10px";
    delete_btn.addEventListener('click', () => {
      task_list.removeChild(li);
    });
    //edit 
    let edit_btn = document.createElement('edit');
    edit_btn.textContent = "Edit";
    edit_btn.style.marginLeft = "20px";
    edit_btn.addEventListener('click', () => {
      let newtask = li.firstChild.textContent;
      if (newtask !== null && newtask.trim() !== "") {
        li.firstChild.textContent = newtask.trim();
      }
    })
    li.appendChild(edit_btn);
    li.appendChild(delete_btn);
    task_list.appendChild(li);

  }
})