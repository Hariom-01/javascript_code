

box1.addEventListener('click',(e)=>{
   document.body.style.backgroundColor="red";
})
box2.addEventListener('click',(e)=>{
  document.body.style.backgroundColor="blue";
})
box3.addEventListener('click',(e)=>{
  document.body.style.backgroundColor="green";
})
box4.addEventListener('click',(e)=>{
  document.body.style.backgroundColor="yellow";
})